<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>Memory Game</title>

    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <section class="memory-game">

        <!--A-->
        <?php
        require_once './ConexaoMysql.php';
        $conexao = new ConexaoMysql();
        $conexao->Conecta();
        $sql = "SELECT nomeArquivo FROM torrent";
        $resultado = $conexao->Consulta($sql);
        ?>
        <?php
        if ($conexao->total != 0) {
            foreach ($resultado as $usuario) {
                ?>
                <div class="memory-card" data-framework="A">
                    <img class="front-face" src="upload/<?php echo $usuario['A1']; ?>" alt="A1" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
                <div class="memory-card" data-framework="A">
                    <img class="front-face" src="upload/<?php echo $usuario['A2']; ?>" alt="A2" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
        <?php
            }
        }

        $conexao->Desconecta();
        ?>

        <!--B -->
        <?php
        require_once './ConexaoMysql.php';
        $conexao = new ConexaoMysql();
        $conexao->Conecta();
        $sql = "SELECT nomeArquivo FROM torrent";
        $resultado = $conexao->Consulta($sql);
        ?>
        <?php
        if ($conexao->total != 0) {
            foreach ($resultado as $usuario) {
                ?>
                <div class="memory-card" data-framework="B">
                    <img class="front-face" src="upload/<?php echo $usuario['B1']; ?>" alt="B1" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
                <div class="memory-card" data-framework="B">
                    <img class="front-face" src="upload/<?php echo $usuario['B2']; ?>" alt="B2" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
        <?php
            }
        }

        $conexao->Desconecta();
        ?>
        <!--C  -->
        <?php
        require_once './ConexaoMysql.php';
        $conexao = new ConexaoMysql();
        $conexao->Conecta();
        $sql = "SELECT nomeArquivo FROM torrent";
        $resultado = $conexao->Consulta($sql);
        ?>
        <?php
        if ($conexao->total != 0) {
            foreach ($resultado as $usuario) {
                ?>
                <div class="memory-card" data-framework="C">
                    <img class="front-face" src="upload/<?php echo $usuario['B1']; ?>" alt="C1" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
                <div class="memory-card" data-framework="C">
                    <img class="front-face" src="upload/<?php echo $usuario['B2']; ?>" alt="C2" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
        <?php
            }
        }

        $conexao->Desconecta();
        ?>
        <!--D-->
        <?php
        require_once './ConexaoMysql.php';
        $conexao = new ConexaoMysql();
        $conexao->Conecta();
        $sql = "SELECT nomeArquivo FROM torrent";
        $resultado = $conexao->Consulta($sql);
        ?>
        <?php
        if ($conexao->total != 0) {
            foreach ($resultado as $usuario) {
                ?>
                <div class="memory-card" data-framework="D">
                    <img class="front-face" src="upload/<?php echo $usuario['B1']; ?>" alt="D1" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
                <div class="memory-card" data-framework="D">
                    <img class="front-face" src="upload/<?php echo $usuario['B2']; ?>" alt="D2" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
        <?php
            }
        }

        $conexao->Desconecta();
        ?>
        <!--E  -->
        <?php
        require_once './ConexaoMysql.php';
        $conexao = new ConexaoMysql();
        $conexao->Conecta();
        $sql = "SELECT nomeArquivo FROM torrent";
        $resultado = $conexao->Consulta($sql);
        ?>
        <?php
        if ($conexao->total != 0) {
            foreach ($resultado as $usuario) {
                ?>
                <div class="memory-card" data-framework="E">
                    <img class="front-face" src="upload/<?php echo $usuario['E1']; ?>" alt="E1" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
                <div class="memory-card" data-framework="E">
                    <img class="front-face" src="upload/<?php echo $usuario['E2']; ?>" alt="E2" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
        <?php
            }
        }

        $conexao->Desconecta();
        ?>
        <!--F-->
        <?php
        require_once './ConexaoMysql.php';
        $conexao = new ConexaoMysql();
        $conexao->Conecta();
        $sql = "SELECT nomeArquivo FROM torrent";
        $resultado = $conexao->Consulta($sql);
        ?>
        <?php
        if ($conexao->total != 0) {
            foreach ($resultado as $usuario) {
                ?>
                <div class="memory-card" data-framework="F">
                    <img class="front-face" src="upload/<?php echo $usuario['F1']; ?>" alt="F1" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
                <div class="memory-card" data-framework="F">
                    <img class="front-face" src="upload/<?php echo $usuario['F2']; ?>" alt="F2" />
                    <img class="back-face" src="img/js-badge.svg" alt="JS Badge" />
                </div>
        <?php
            }
        }

        $conexao->Desconecta();
        ?>
    </section>

    <script src="scripts.js"></script>
</body>

</html>