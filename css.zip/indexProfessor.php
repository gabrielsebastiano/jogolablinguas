<!DOCTYPE html>
<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['adicionaMenu'] = 'deslogado';
}
?>
<html lang="PT-BR">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Jogo da Memoria - LabLinguas</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    </head>

    <body>

        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#"><img src="img/logo.png" style="height: 30px;align-content: center;"></a>
                </div>

                <ul class="nav navbar-nav navbar-right">

                    <li> Bem vindo(a):<a href="logout.php"><i class="fa fa-sign-out-alt"></i>
                            Sair</a></li>

                </ul>
            </div>
        </nav>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs">

            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#criar">Criar</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#jogos">Jogos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#usuarios">Usuários</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#ajuda">Ajuda</a>
            </li>


        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <div class="tab-pane container fade" id="criar">
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card bg-light">
                                <div class="card-header">
                                    Criar jogos<button class="btn btn-secondary btn-sm ml-2"><i class="fa fa-question-circle"></i> Ajuda</button>
                                </div>
                                <div class="card-body">
                                    <form action="#" method="POST" enctype="multipart/form-data">
                                        <!-- A -->
                                        <div class="form-group">
                                            <label>Texto A</label>
                                            <input type="text" class="form-control" name="a" placeholder="Nome do arquivo ex(Meu malvado favorito)">
                                            <small id="emailHelp" class="form-text text-muted">Coloque um nome que faça sentido com
                                                o conteúdo no qual você está inserindo.
                                            </small>
                                        </div>

                                        <!-- ENVIO DO ARQUIVO -->

                                        <div class="form-group">
                                            <label>Imagem A</label>
                                            <input accept="image/jpeg,image/png,image/jpg" type="file" class="form-control-file" name="fileUpload[]">
                                        </div>
                                        <!--/ A -->
                                        <!-- B -->
                                        <div class="form-group">
                                            <label>Texto B</label>
                                            <input type="text" class="form-control" name="b" placeholder="Nome do arquivo ex(Meu malvado favorito)">
                                            <small id="emailHelp" class="form-text text-muted">Coloque um nome que faça sentido com
                                                o conteúdo no qual você está inserindo.
                                            </small>
                                        </div>

                                        <!-- ENVIO DO ARQUIVO -->

                                        <div class="form-group">
                                            <label>Imagem B</label>
                                            <input type="file" class="form-control-file" name="fileUpload[]">
                                        </div>
                                        <!--/ B -->

                                        <input type="submit" class="btn btn-primary" value="Enviar">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="tab-pane container active" id="jogos">
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card bg-light">
                                <div class="card-header">
                                    Jogos
                                </div>
                                <div class="card-body">
                                    <?php
                                    require_once './ConexaoMysql.php';
                                    $conexao = new ConexaoMysql();
                                    $conexao->Conecta();
                                    $sql = "SELECT idJogo, usuario.idUsuario, usuario.nome as nomeUsuario,DATE_FORMAT((DATE(jogo.dataCriacao)), '%d/%m/%Y') as dataAtualizada, tituloJogo,usuario.turma as turma FROM `jogo` INNER JOIN usuario ON jogo.idUsuario = usuario.idUsuario";
                                    $resultado = $conexao->Consulta($sql);
                                    ?>
                                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th scope="col"></th>
                                                <th scope="col">Nome jogo</th>
                                                <th scope="col">Criador</th>
                                                <th scope="col">Turma</th>
                                                <th scope="col">Data de Criação</th>
                                                <th scope="col">#</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($conexao->total != 0) {
                                                foreach ($resultado as $usuario) {
                                                    $idUser = $usuario['idJogo'];
                                                    ?>
                                                    <tr>
                                                        <td style="text-align:center;vertical-align:middle;">
                                                            <a href="#" onclick="open('jogo/index.php?id=<?php echo $idUser; ?>', '', 'status=no,Width=750,Height=800');"><img src="img/jogo.png" style="height: 40px;"></a>
                                                        </td>
                                                        <td>
                                                            <a><?php echo $usuario['tituloJogo']; ?></a>
                                                        </td>
                                                        <td><?php echo $usuario['nomeUsuario']; ?></td>
                                                        <td><?php echo $usuario['turma'];
                                                    ?></td>
                                                        <td><?php echo $usuario['dataAtualizada']; ?></td>
                                                        <td>
                                                            <div class="text-center"> 
                                                                <form name="excluir" method="POST" action="indexModel.php">
                                                                    <button type="submit" class="btn btn-xs btn-danger" name="jogoDelete" type="hidden" class="form-control" value="<?php echo $idUser; ?>">Apagar</button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            }

                                            $conexao->Desconecta();
                                            ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="tab-pane container" id="usuarios">
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card bg-light">
                                <div class="card-header">
                                    Usuários para aprovação
                                </div>
                                <div class="card-body">
                                    <?php
                                    require_once './ConexaoMysql.php';
                                    $conexao = new ConexaoMysql();
                                    $conexao->Conecta();
                                    $sql = "SELECT idUsuario,nome,turma,login,DATE_FORMAT((DATE(dataCriacao)), '%d/%m/%Y') as dataAtualizada,status,tipo FROM usuario WHERE status = 0";

                                    $resultado = $conexao->Consulta($sql);
                                    ?>
                                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th scope="col">Nome</th>
                                                <th scope="col">Turma</th>
                                                <th scope="col">Login</th>
                                                <th scope="col">Data de Criação</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">#</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($conexao->total != 0) {
                                                foreach ($resultado as $usuario) {
                                                    $idUser = $usuario['idUsuario'];
                                                    ?>
                                                    <tr>

                                                        <td>
                                                            <a><?php echo $usuario['nome']; ?></a>
                                                        </td>
                                                        <td><?php echo $usuario['turma']; ?></td>
                                                        <td><?php echo $usuario['login']; ?></td>
                                                        <td><?php echo $usuario['dataAtualizada']; ?></td>
                                                        <td><?php echo $usuario['status']; ?></td>
                                                        <td><?php
                                                            if ($usuario['tipo'] = 1) {
                                                                echo 'Aluno';
                                                            } else if ($usuario['tipo'] = 2) {
                                                                echo 'Professor';
                                                            }
                                                            ?></td>
                                                        <td>
                                                            <div class="text-center">

                                                                <form name="usuarioUpdate" method="POST" action="indexModel.php">
                                                                    <button type="submit" class="btn btn-xs btn-success" name="usuarioUpdate" type="hidden" class="form-control" value="<?php echo $idUser; ?>">Aprovar</button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            }

                                            $conexao->Desconecta();
                                            ?>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card bg-light">
                                <div class="card-header">
                                    Usuários ativos
                                </div>
                                <div class="card-body">
                                    <?php
                                    require_once './ConexaoMysql.php';
                                    $conexao = new ConexaoMysql();
                                    $conexao->Conecta();
                                    $sql = "SELECT idUsuario,nome,turma,login,DATE_FORMAT((DATE(dataCriacao)), '%d/%m/%Y') as dataAtualizada,status,tipo FROM usuario WHERE status = 1";

                                    $resultado = $conexao->Consulta($sql);
                                    ?>
                                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th scope="col">Nome</th>
                                                <th scope="col">Turma</th>
                                                <th scope="col">Login</th>
                                                <th scope="col">Data de Criação</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">#</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($conexao->total != 0) {
                                                foreach ($resultado as $usuario) {
                                                    $idUser = $usuario['idUsuario'];
                                                    ?>
                                                    <tr>

                                                        <td>
                                                            <a><?php echo $usuario['nome']; ?></a>
                                                        </td>
                                                        <td><?php echo $usuario['turma']; ?></td>
                                                        <td><?php echo $usuario['login']; ?></td>
                                                        <td><?php echo $usuario['dataAtualizada']; ?></td>
                                                        <td><?php echo $usuario['status']; ?></td>
                                                        <td><?php
                                            if ($usuario['tipo'] = 1) {
                                                echo 'Aluno';
                                            } else {
                                                echo 'Professor';
                                            }
                                                    ?></td>
                                                        <td>
                                                            <div class="text-center">

                                                                <form name="usuarioUpdate" method="POST" action="indexModel.php">
                                                                    <button type="submit" class="btn btn-xs btn-danger" name="usuarioDelete" type="hidden" class="form-control" value="<?php echo $idUser; ?>">Remover</button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            }

                                            $conexao->Desconecta();
                                            ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <br>
            </div>

            <div class="tab-pane container fade" id="ajuda">Sobre o jogo??</div>
        </div>






    </body>

</html>