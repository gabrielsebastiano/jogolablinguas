<?php

require_once './ConexaoMysql.php';


if (@$_POST['usuarioCadastro']) {

    $nome = $_POST['nome'];
    $turma = $_POST['turma'];
    $usuarioPost = $_POST['usuario'];
    $senhaPost = $_POST['senha'];
    $tipo = $_POST['tipo'];

    $senhaNova = md5($senhaPost);

    require_once './ConexaoMysql.php';
    $conexao = new ConexaoMysql();
    $conexao->Conecta();
    $conexao->Consulta($sql1);
    $sql1 = "SELECT usuario FROM usuario";
    if ($conexao->total < 1) {
        header('location:index.php?msg=' . $msg);
        $conexao->Desconecta();
    } else {
        $sql = "INSERT INTO usuario (nome,turma,login,senha,dataCriacao,status,tipo) VALUES ('$nome','$turma','$usuarioPost','$senhaNova',CURDATE( ),0,$tipo);";
        $conexao->Executa($sql);

        header('location:index.php?msg=' . $msg);
    }
}
if (@$_POST['usuarioUpdate']) {
    $conexao = new ConexaoMysql();
    $conexao->Conecta();
    echo $sql = "UPDATE usuario SET status = 1 WHERE idUsuario =" . $_POST['usuarioUpdate'];
    $conexao->Executa($sql);
    $conexao->Desconecta();
    $msg = md5('cadastro');
    header('location:indexProfessor.php?msg=' . $msg);
}

if (@$_POST['usuarioDelete']) {
    $conexao = new ConexaoMysql();
    $conexao->Conecta();
    echo $sql = "UPDATE usuario SET status = 3 WHERE idUsuario =" . $_POST['usuarioDelete'];
    $conexao->Executa($sql);
    $conexao->Desconecta();
    $msg = md5('cadastro');
    header('location:indexProfessor.php?msg=' . $msg);
}

if (@$_POST['jogoDelete']) {
    $conexao = new ConexaoMysql();
    $conexao->Conecta();
    echo $sql = "DELETE FROM jogo WHERE idJogo =" . $_POST['jogoDelete'];
    $conexao->Executa($sql);
    $conexao->Desconecta();
    $msg = md5('cadastro');
    header('location:indexProfessor.php?msg=' . $msg);
}
