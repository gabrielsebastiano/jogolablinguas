<?php

// Script para deletar arquivos
// permissao 777
// unlink -> função do php para deletar arquivo 
$arquivo = "upload/hydrangeas.jpg_2019.10.21-09.54.55.jpg";

if ($arquivo) {
    if (file_exists($arquivo)) {
        unlink($arquivo);
        echo("<font color=\"green\">" . $arquivo . " deletado com sucesso!!");
    } else {
        echo("<font color=\"red\">" . $arquivo . " não existe!</font>");
    }
} else {
    echo"Especifique o nome do arquivo.";
}
?>        echo $sql = "INSERT INTO `jogo`(`A1`, `A2`) VALUES ('A1', $nomeArquivo[0], 'A2', $nomeArquivo[1])";
